# showmyscreen

### Share your screen by browser

> This helps me share my screens with my students in class.

![Demo](showscreen.gif)
